package com.hidalgo.parcial.data.network.entities

data class ResultMessage(
    val message: String,
    val name: String,
    val profile_image: String
)