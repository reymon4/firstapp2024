package com.hidalgo.parcial.data.network.entities

data class Meta(
    val items: Int,
    val last: Int,
    val page: Int
)